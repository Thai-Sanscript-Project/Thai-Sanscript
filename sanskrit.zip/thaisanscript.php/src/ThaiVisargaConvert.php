<?php

/**
 * Description of ThaiVisargaConvert
 *
 * @author Thanakrit.P
 */
class ThaiVisargaConvert {
    //put your code here
}
