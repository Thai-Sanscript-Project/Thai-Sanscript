<?php
include '../src/ThaiSanscriptAPI.php';
include '../src/ThaiSanscriptRule.php';
include '../src/ThaiSanscriptInformRule.php';
include '../src/ThaiVisargaRuleConvert.php';
include '../src/Util.php';
include '../src/ThaiSanscript.php';
