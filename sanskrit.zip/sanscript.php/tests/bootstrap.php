<?php

$loader = require __DIR__ . "/../vendor/autoload.php";
$loader->addPsr4('Sanskrit\\Sanscript\\Tests\\', __DIR__);
