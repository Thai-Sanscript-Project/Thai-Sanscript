
<header>
    <div class="header-content">
        <div class="header-content-inner">
            <h2></h2>
            <h2></h2>
            <p>
                ไทย-สันสคริปท์ เป็นโปรแกรมช่วยในการปริวรรต(Transliterate) จาก โรมาไนซ์-สันสฤต มาเป็น ไทย-สันสฤต
                ไทย-สันสคริปท์ เป็นโปรแกรมที่พัฒนาต่อยอด จากโปรแกรม สันสคริปท์ (learnsanskrit.org) ที่ฟีเจอร์ในการปริวรรต  จาก เทวนาครี-สันสฤต มาเป็น โรมาไนซ์-สันสฤต 
                ตามมาตรฐาน International Alphabet of Sanskrit Transliteration (IAST)<br>
                ไทย-สันสคริปท์ เป็นแต่เพียงเครื่องมือช่วยในการปริวรรตเท่านั้น ผลลัพท์จากโปรแกรมนี้อาจยังมีบางส่วนที่ยังผิดพลาดอยู่ ควรตรวจทานอีกรอบก่อนใช้งานจริง
            </p>
            <a href="#about" class="btn btn-primary btn-xl page-scroll">ยอมรับ เริ่มต้นกันเลย !!</a>
        </div>
    </div>
</header>
