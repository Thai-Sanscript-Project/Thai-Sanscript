<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<?php $this->load->view('welcome_message/main'); ?>

<?php $this->load->view('welcome_message/about'); ?>

<?php $this->load->view('welcome_message/document'); ?>

<?php $this->load->view('welcome_message/portfolio'); ?>

<?php $this->load->view('welcome_message/services'); ?>
